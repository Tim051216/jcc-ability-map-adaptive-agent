package com.cnsoftbei.a3.api.client.promotion.fallback;

import com.cnsoftbei.a3.api.client.promotion.PromotionClient;
import com.cnsoftbei.a3.api.dto.promotion.CouponDiscountDTO;
import com.cnsoftbei.a3.api.dto.promotion.OrderCouponDTO;
import com.cnsoftbei.a3.api.dto.promotion.OrderCourseDTO;
import com.cnsoftbei.a3.common.exceptions.BizIllegalException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.openfeign.FallbackFactory;

import java.util.Collections;
import java.util.List;

@Slf4j
public class PromotionClientFallback implements FallbackFactory<PromotionClient> {

    //降级后返回的对象
    @Override
    public PromotionClient create(Throwable cause) {
        log.error("查询促销服务出现异常，", cause);
        return new PromotionClient() {
            @Override
            public List<CouponDiscountDTO> findDiscountSolution(List<OrderCourseDTO> orderCourses) {
                return Collections.emptyList();
            }

            @Override
            public CouponDiscountDTO queryDiscountDetailByOrder(OrderCouponDTO orderCouponDTO) {
                return null;
            }

            @Override
            public void writeOffCoupon(List<Long> userCouponIds) {
                throw new BizIllegalException(500, "核销优惠券异常", cause);
            }
        };
    }
}
