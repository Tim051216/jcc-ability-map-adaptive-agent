"""Java service clients."""
