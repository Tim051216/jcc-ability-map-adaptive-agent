"""Narrow public gateway used by the Xfyun job-learning plugin demo."""

from __future__ import annotations

import asyncio
import os
from time import monotonic
from typing import Any

import httpx
from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import JSONResponse

BACKEND_BASE_URL = os.getenv("PLUGIN_BACKEND_BASE_URL", "http://127.0.0.1:18080").rstrip("/")
CACHE_TTL_SECONDS = float(os.getenv("PLUGIN_CACHE_TTL_SECONDS", "300"))

_response_cache: dict[tuple[int, int], tuple[float, dict[str, Any]]] = {}
_cache_lock = asyncio.Lock()

app = FastAPI(
    title="Xfyun Job Learning Plugin Gateway",
    docs_url=None,
    redoc_url=None,
    openapi_url=None,
)


@app.middleware("http")
async def add_public_response_headers(request, call_next):
    response = await call_next(request)
    response.headers["Cache-Control"] = "no-store"
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Robots-Tag"] = "noindex, nofollow"
    return response


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok", "service": "xfyun-job-learning-plugin"}


@app.get("/api/v1/student-portal/job-learning")
async def get_job_learning_overview(
    user_id: int = Query(default=1001, ge=1),
    course_id: int = Query(default=401, ge=1),
) -> JSONResponse:
    payload, cache_status = await _load_job_learning_overview(user_id, course_id)
    return JSONResponse(content=payload, headers={"X-Plugin-Cache": cache_status})


@app.get("/api/v1/xa/industry-analysis")
async def get_xa_industry_analysis(
    user_id: int = Query(default=1001, ge=1),
    course_id: int = Query(default=401, ge=1),
) -> JSONResponse:
    payload, cache_status = await _load_job_learning_overview(user_id, course_id)
    result = {
        "route": "industry_analysis",
        "professional_group": payload.get("professional_group"),
        "target_job": payload.get("job_name"),
        "course_code": payload.get("course_code"),
        "course_name": payload.get("course_name"),
        "student_goal": payload.get("student_goal"),
        "goal_scene": payload.get("goal_scene"),
        "assessment_id": payload.get("assessment_id"),
        "competency_benchmarks": [
            {
                "code": item.get("code"),
                "label": item.get("label"),
                "benchmark": item.get("benchmark"),
            }
            for item in payload.get("ability_dimensions", [])
        ],
        "gap_summary": payload.get("weak_abilities", []),
        "citations": payload.get("citations", []),
        "safety_notices": payload.get("safety_notices", []),
    }
    return JSONResponse(content=result, headers={"X-Plugin-Cache": cache_status})


@app.get("/api/v1/xa/ability-map")
async def get_xa_ability_map(
    user_id: int = Query(default=1001, ge=1),
    course_id: int = Query(default=401, ge=1),
) -> JSONResponse:
    payload, cache_status = await _load_job_learning_overview(user_id, course_id)
    result = {
        "route": "ability_map",
        "user_id": payload.get("user_id"),
        "course_id": payload.get("course_id"),
        "target_job": payload.get("job_name"),
        "assessment_id": payload.get("assessment_id"),
        "assessment_updated_at": payload.get("assessment_updated_at"),
        "ability_dimensions": payload.get("ability_dimensions", []),
        "weak_abilities": payload.get("weak_abilities", []),
        "next_action": payload.get("next_action"),
    }
    return JSONResponse(content=result, headers={"X-Plugin-Cache": cache_status})


@app.get("/api/v1/xa/task-cards")
async def get_xa_task_cards(
    user_id: int = Query(default=1001, ge=1),
    course_id: int = Query(default=401, ge=1),
) -> JSONResponse:
    payload, cache_status = await _load_job_learning_overview(user_id, course_id)
    result = {
        "route": "task_cards",
        "user_id": payload.get("user_id"),
        "course_id": payload.get("course_id"),
        "student_goal": payload.get("student_goal"),
        "task_cards": payload.get("recommended_path", []),
        "recommended_resources": payload.get("recommended_resources", []),
        "safety_notices": payload.get("safety_notices", []),
    }
    return JSONResponse(content=result, headers={"X-Plugin-Cache": cache_status})


@app.get("/api/v1/xa/adaptive-recommendations")
async def get_xa_adaptive_recommendations(
    user_id: int = Query(default=1001, ge=1),
    course_id: int = Query(default=401, ge=1),
) -> JSONResponse:
    payload, cache_status = await _load_job_learning_overview(user_id, course_id)
    result = {
        "route": "adaptive_recommendations",
        "user_id": payload.get("user_id"),
        "course_id": payload.get("course_id"),
        "assessment_id": payload.get("assessment_id"),
        "weak_abilities": payload.get("weak_abilities", []),
        "recommended_path": payload.get("recommended_path", []),
        "recommended_resources": payload.get("recommended_resources", []),
        "citations": payload.get("citations", []),
        "safety_notices": payload.get("safety_notices", []),
        "ai_generated": payload.get("ai_generated", False),
        "next_action": payload.get("next_action"),
    }
    return JSONResponse(content=result, headers={"X-Plugin-Cache": cache_status})


async def _load_job_learning_overview(
    user_id: int,
    course_id: int,
) -> tuple[dict[str, Any], str]:
    cache_key = (user_id, course_id)
    cached = _response_cache.get(cache_key)
    if cached and monotonic() - cached[0] < CACHE_TTL_SECONDS:
        return cached[1], "hit"

    async with _cache_lock:
        cached = _response_cache.get(cache_key)
        if cached and monotonic() - cached[0] < CACHE_TTL_SECONDS:
            return cached[1], "hit"

        try:
            async with httpx.AsyncClient(timeout=40.0, trust_env=False) as client:
                upstream = await client.get(
                    f"{BACKEND_BASE_URL}/api/v1/student-portal/job-learning",
                    params={"user_id": user_id, "course_id": course_id},
                )
            if upstream.status_code != 200:
                raise HTTPException(
                    status_code=502,
                    detail="job-learning backend returned an error",
                )
            payload = upstream.json()
        except (httpx.TimeoutException, httpx.HTTPError) as exc:
            if cached:
                return cached[1], "stale"
            status_code = 504 if isinstance(exc, httpx.TimeoutException) else 502
            detail = (
                "job-learning backend timed out"
                if status_code == 504
                else "job-learning backend unavailable"
            )
            raise HTTPException(status_code=status_code, detail=detail) from exc

        _response_cache[cache_key] = (monotonic(), payload)
        return payload, "miss"
